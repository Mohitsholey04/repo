# from rest_framework.generics import CreateAPIView
# from .serializers import LoginSerializer, RegisterSerializer, Userserializer
# from django.contrib.auth.models import User
# from rest_framework.permissions import AllowAny
# from django.contrib.auth import authenticate
# from rest_framework.permissions import IsAuthenticated
# from rest_framework_simplejwt.tokens import RefreshToken
# from rest_framework.response import Response
# from rest_framework.views import APIView

# class RegisterView(CreateAPIView):
#     queryset = User.objects.all()
#     permission_classes = (AllowAny,)
#     serializer_class = RegisterSerializer


# class LoginView(CreateAPIView):
#     serializer_class = LoginSerializer

#     def post(self, request, *args, **kwargs):
#         username = request.data.get('username')
#         password = request.data.get('password')
#         user = authenticate(request, username=username, password=password)

#         if user is not None:
#             refresh = RefreshToken.for_user(user)
#             user_serialized = Userserializer(user)
#             return Response({
#                 'user': user_serialized.data,
#                 'refresh': str(refresh),
#                 'access': str(refresh.access_token),
#             })
#         else:
#             return Response({'error': 'Invalid credentials'}, status=401)
        
# class DashboardView(APIView):
#     permission_classes = (IsAuthenticated,)
#     def get(self, request):
#         user = request.user
#         user_serialized = Userserializer(user)
#         return Response({
#             'message': 'You are authenticated',
#             'user': user_serialized.data
#         },200)
    
from rest_framework.generics import CreateAPIView
from .serializers import LoginSerializer, RegisterSerializer, Userserializer
from .models import CustomUser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import BasePermission

# Custom Permission for Admin
class IsAdminUser(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'admin'

# User Registration
class RegisterView(CreateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

    def perform_create(self, serializer):
        serializer.save(role='customer')  # Default role is customer

# Admin Creation (Only Admins can create other Admins)
class CreateAdminView(CreateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = (IsAuthenticated, IsAdminUser)  # Only admins allowed
    serializer_class = RegisterSerializer

    def perform_create(self, serializer):
        serializer.save(role='admin')

# Login View
class LoginView(CreateAPIView):
    serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            refresh = RefreshToken.for_user(user)
            user_serialized = Userserializer(user)
            return Response({
                'user': user_serialized.data,
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            })
        else:
            return Response({'error': 'Invalid credentials'}, status=401)

# Dashboard View for Authenticated Users
class DashboardView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        user = request.user
        user_serialized = Userserializer(user)
        return Response({
            'message': 'You are authenticated',
            'user': user_serialized.data
        }, status=200)

# Example View Restricted to Admins Only
class AdminOnlyView(APIView):
    permission_classes = (IsAuthenticated, IsAdminUser)

    def get(self, request):
        return Response({'message': 'Welcome Admin!'}, status=200)
